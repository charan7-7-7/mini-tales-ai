# Streamlit app entry point
import streamlit as st
st.title('MiniTales AI')